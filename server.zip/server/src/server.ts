import { NONAME } from 'dns';
import express from 'express';
import * as http from 'http';
import * as WebSocket from 'ws';

interface CustomWebSocket extends WebSocket {
  intervalId?: NodeJS.Timeout;
  clientId?: string;
}

const generateClientId = () => {
  return `client_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
};

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ noServer:true });

const connectedClients: CustomWebSocket[] = [];

wss.on('connection', (ws: CustomWebSocket) => {
  console.log('Client connected');

  // Assign a custom client ID to the WebSocket connection
  ws.clientId = generateClientId();

  // Send a welcome message to the client
  ws.send(`Welcome to the WebSocket server, ${ws.clientId}!`);

  // Handle messages from the client
  ws.on('message', (message) => {
    console.log(`Received from ${ws.clientId}: ${message}`);
  });

  // Store the connected client
  connectedClients.push(ws);

  // Handle the WebSocket connection closing
  ws.on('close', () => {
    console.log(`Client ${ws.clientId} disconnected`);

    // Remove the client from the connectedClients array
    const index = connectedClients.indexOf(ws);
    if (index !== -1) {
      connectedClients.splice(index, 1);
    }
  });

  // Set up periodic message sending for the specific client
  const clientIntervalId = setInterval(() => {
    const timestamp = Date.now();
    ws.send(`Periodic message from server to ${ws.clientId}: ${timestamp}`);
  }, 5000); // Send a message every 5 seconds (adjust as needed)

  // Store the interval ID for later cleanup
  ws.intervalId = clientIntervalId;
});

// API endpoint to get all connected clients
app.get('/api/connected-clients', (req, res) => {
    const clientInfo = connectedClients.map((client) => ({
      clientId: client.clientId,
    }));
    res.json(clientInfo);
  });

// Set up periodic message sending for all connected clients
const broadcastInterval = setInterval(() => {
  const timestamp = Date.now();
  connectedClients.forEach((client) => {
    client.send(`${timestamp}`);
  });
}, 10000); // Send a broadcast message every 10 seconds (adjust as needed)

server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request, wss);
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
