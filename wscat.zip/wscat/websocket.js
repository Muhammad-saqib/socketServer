const socket = new WebSocket('ws://localhost:3000');

socket.onopen = () => {
  console.log('Connected to WebSocket server');
};

socket.onmessage = (event) => {
  console.log('Received:', event.data);
};

socket.onclose = () => {
  console.log('Connection closed');
};

// Send a message to the server
socket.send('Hello, WebSocket Server!');
